import argparse
import json
import sys
from pathlib import Path

import httpx


def pretty(data):
    return json.dumps(data, ensure_ascii=False, indent=2)


def main():
    parser = argparse.ArgumentParser(description="ARCH 운영 방식 수정 API 테스트")
    parser.add_argument("--host", default="http://localhost:8000")
    parser.add_argument("--project-sn", type=int, default=1)
    parser.add_argument("--meeting-file-sn", type=int, nargs="+", default=[2])
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("--save", default="request/responses/arch_update_operating_response.json")
    args = parser.parse_args()

    payload = {
        "project_sn": args.project_sn,
        "docs_cd": "ARCH",
        "udt_yn": "Y",
        "file_list": args.meeting_file_sn,
        "image_list": [],
        "etc": {
            "debug": True
        }
    }

    url = f"{args.host.rstrip('/')}/generate"

    print("=" * 100)
    print("[POST]", url)
    print("[PAYLOAD]")
    print(pretty(payload))
    print("=" * 100)

    try:
        response = httpx.post(url, json=payload, timeout=args.timeout)
    except Exception as exc:
        print("[REQUEST ERROR]", type(exc).__name__, exc)
        sys.exit(1)

    print("[HTTP STATUS]", response.status_code)

    try:
        data = response.json()
    except Exception:
        print(response.text)
        sys.exit(1)

    print("[RESPONSE]")
    print(pretty(data))

    save_path = Path(args.save)
    save_path.parent.mkdir(parents=True, exist_ok=True)
    save_path.write_text(pretty(data), encoding="utf-8")
    print("[SAVED]", save_path.resolve())

    result = data.get("result") or {}
    agent_outputs = result.get("agent_outputs") or {}
    errors = result.get("errors") or []

    document_merge = agent_outputs.get("document_merge_agent") or {}
    arch_output = agent_outputs.get("architecture_analysis_agent") or {}
    final_document_json = result.get("final_document_json") or {}

    print("\n" + "=" * 100)
    print("[SUMMARY]")
    print("status:", data.get("status"))
    print("next_action:", result.get("next_action"))
    print("agent_outputs_keys:", list(agent_outputs.keys()))
    print("errors_count:", len(errors))
    print("has document_merge_agent:", bool(document_merge))
    print("has architecture_analysis_agent:", bool(arch_output))
    print("has final_document_json:", bool(final_document_json))

    if errors:
        print("\n[ERRORS]")
        for error in errors:
            print("-", error.get("code"), ":", error.get("message"))

    print("\n[DOCUMENT MERGE CHECK]")
    print("document_merge status:", document_merge.get("status"))
    print("document_merge keys:", list(document_merge.keys()))
    print("has existing_output_raw_json:", bool(document_merge.get("existing_output_raw_json")))
    print("has meeting_change_items:", bool(document_merge.get("meeting_change_items")))

    existing = document_merge.get("existing_output_raw_json") or {}
    changes = document_merge.get("meeting_change_items") or []

    if isinstance(existing, dict):
        print("existing_output_raw_json keys:", list(existing.keys()))
        print("existing has architecture_structure_json:", bool(existing.get("architecture_structure_json")))
        print("existing has components:", bool(existing.get("components")))

    print("\n[MEETING CHANGE ITEMS]")
    print(pretty(changes))

    actionable_changes = []
    for change in changes:
        if not isinstance(change, dict):
            continue
        item = change.get("item") if isinstance(change.get("item"), dict) else change
        if item.get("component_id") or item.get("component_name") or item.get("name"):
            actionable_changes.append(change)

    print("actionable_change_count:", len(actionable_changes))

    print("\n[ARCH OUTPUT CHECK]")
    print("arch status:", arch_output.get("status"))
    print("arch keys:", list(arch_output.keys()))
    print("has architecture_structure_json:", bool(arch_output.get("architecture_structure_json")))
    print("has architecture_document_json:", bool(arch_output.get("architecture_document_json")))

    if data.get("status") == "FAILED":
        sys.exit(2)

    if not document_merge:
        print("[FAILED] document_merge_agent가 실행되지 않았습니다.")
        sys.exit(3)

    if not arch_output:
        print("[FAILED] architecture_analysis_agent가 실행되지 않았습니다.")
        sys.exit(4)

    if not document_merge.get("existing_output_raw_json"):
        print("[FAILED] 기존 산출물 JSON이 document_merge_agent에서 나오지 않았습니다.")
        sys.exit(5)

    if not document_merge.get("meeting_change_items"):
        print("[FAILED] 회의록 변경사항이 document_merge_agent에서 나오지 않았습니다.")
        sys.exit(6)

    if not actionable_changes:
        print("[WARN] meeting_change_items는 있지만 component_id/name이 없어 실제 컴포넌트 변경에 쓰기 어렵습니다.")

    print("\n[DONE] ARCH 운영 방식 수정 API 흐름 확인 완료")


if __name__ == "__main__":
    main()