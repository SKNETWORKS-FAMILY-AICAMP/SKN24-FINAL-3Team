import argparse
import json
import sys
from pathlib import Path

import httpx


HOST="http://localhost:8000"
PROJECT_SN=1

REQUEST_CASES={
    "SRS":{
        "project_sn":PROJECT_SN,
        "docs_cd":"SRS",
        "udt_yn":"N",
        "file_list":[3,2],
        "image_list":[],
        "etc":{"debug":True},
    },
    "INTERFACE":{
        "project_sn":PROJECT_SN,
        "docs_cd":"INTERFACE",
        "udt_yn":"N",
        "file_list":[],
        "image_list":[24,25,26,27,28,29,30,31,32,33],
        "etc":{"debug":True},
    },
    "ERD":{
        "project_sn":PROJECT_SN,
        "docs_cd":"ERD",
        "udt_yn":"N",
        "file_list":[2],
        "image_list":[],
        "etc":{"debug":True},
    },
    "ARCH":{
        "project_sn":PROJECT_SN,
        "docs_cd":"ARCH",
        "udt_yn":"N",
        "file_list":[2],
        "image_list":[],
        "etc":{"debug":True},
    },
}


def pretty(data):
    return json.dumps(data,ensure_ascii=False,indent=2)


def health_check(base_url:str):
    url=f"{base_url.rstrip('/')}/health"
    print("="*100)
    print("[HEALTH]",url)
    try:
        res=httpx.get(url,timeout=30)
        print("[HEALTH STATUS]",res.status_code)
        print(res.text)
        return res.status_code<400
    except Exception as exc:
        print("[HEALTH ERROR]",type(exc).__name__,exc)
        return False


def run_generate(base_url:str,payload:dict,timeout:int,save_path:Path):
    url=f"{base_url.rstrip('/')}/generate"
    print("="*100)
    print("[POST]",url)
    print("[PAYLOAD]")
    print(pretty(payload))
    print("="*100)

    try:
        with httpx.Client(timeout=timeout) as client:
            res=client.post(url,json=payload)
    except httpx.ConnectError as exc:
        print("[ERROR] 서버 연결 실패")
        print("uvicorn 실행 확인:")
        print("python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload")
        print(exc)
        sys.exit(1)
    except httpx.TimeoutException as exc:
        print("[ERROR] 요청 timeout")
        print(exc)
        sys.exit(1)
    except Exception as exc:
        print("[ERROR]",type(exc).__name__,exc)
        sys.exit(1)

    print("[HTTP STATUS]",res.status_code)

    try:
        data=res.json()
    except Exception:
        print("[RAW RESPONSE]")
        print(res.text)
        sys.exit(1)

    print("[RESPONSE]")
    print(pretty(data))

    save_path.parent.mkdir(parents=True,exist_ok=True)
    save_path.write_text(pretty(data),encoding="utf-8")
    print("[SAVED]",save_path.resolve())

    summarize(data)

    if res.status_code>=400:
        sys.exit(1)
    if data.get("status")=="FAILED":
        sys.exit(2)

    return data


def summarize(data:dict):
    result=data.get("result") or {}
    agent_outputs=result.get("agent_outputs") or {}
    final_document_json=result.get("final_document_json")
    export_result=result.get("export_result")
    errors=result.get("errors") or []
    warnings=result.get("warnings") or []

    print("\n"+"="*100)
    print("[SUMMARY]")
    print("project_sn:",data.get("project_sn"))
    print("docs_cd:",data.get("docs_cd"))
    print("status:",data.get("status"))
    print("next_action:",result.get("next_action"))
    print("has_final_document_json:",bool(final_document_json))
    print("has_export_result:",bool(export_result))
    print("agent_outputs_keys:",list(agent_outputs.keys()))
    print("errors_count:",len(errors))
    print("warnings_count:",len(warnings))

    if errors:
        print("\n[ERRORS]")
        for error in errors:
            print("-",error.get("code"),":",error.get("message"))

    if warnings:
        print("\n[WARNINGS]")
        for warning in warnings:
            print("-",warning)

    if agent_outputs:
        print("\n[AGENT OUTPUTS]")
        for agent_name,output in agent_outputs.items():
            if isinstance(output,dict):
                print("-",agent_name,"| status:",output.get("status"),"| keys:",list(output.keys()))
            else:
                print("-",agent_name,"|",type(output).__name__)

    if final_document_json:
        print("\n[FINAL_DOCUMENT_JSON_KEYS]")
        print(list(final_document_json.keys()))

    if export_result:
        print("\n[EXPORT_RESULT]")
        print(pretty(export_result))

    print("="*100)


def main():
    parser=argparse.ArgumentParser(description="ALPLED /generate httpx 테스트")
    parser.add_argument("--case",choices=list(REQUEST_CASES.keys())+["ALL"],default="ARCH")
    parser.add_argument("--host",default=HOST)
    parser.add_argument("--project-sn",type=int,default=PROJECT_SN)
    parser.add_argument("--timeout",type=int,default=300)
    parser.add_argument("--no-health",action="store_true")
    parser.add_argument("--out-dir",default="request/responses")
    args=parser.parse_args()

    if not args.no_health:
        ok=health_check(args.host)
        if not ok:
            print("[STOP] health check 실패")
            sys.exit(1)

    cases=list(REQUEST_CASES.keys()) if args.case=="ALL" else [args.case]

    for case_name in cases:
        payload=dict(REQUEST_CASES[case_name])
        payload["project_sn"]=args.project_sn

        save_path=Path(args.out_dir)/f"{case_name.lower()}_generate_response.json"
        data=run_generate(args.host,payload,args.timeout,save_path)

        if case_name=="ARCH":
            result=data.get("result") or {}
            agent_outputs=result.get("agent_outputs") or {}
            arch_output=agent_outputs.get("architecture_analysis_agent") or {}

            print("\n[ARCH CHECK]")
            print("has architecture_analysis_agent:",bool(arch_output))
            print("has architecture_structure_json:",bool(arch_output.get("architecture_structure_json")))
            print("has architecture_document_json:",bool(arch_output.get("architecture_document_json")))

            if not arch_output:
                print("[ARCH CHECK FAILED] architecture_analysis_agent가 실행되지 않았습니다.")
            elif not arch_output.get("architecture_structure_json"):
                print("[ARCH CHECK FAILED] architecture_structure_json이 없습니다.")
            elif not arch_output.get("architecture_document_json"):
                print("[ARCH CHECK FAILED] architecture_document_json이 없습니다.")
            else:
                print("[ARCH CHECK OK] 아키텍처 에이전트 출력 확인 완료")


if __name__=="__main__":
    main()